# Secure Chatbot Starter (Next.js + JWT cookie + allowlist + quota)

## Env vars
- OPENAI_API_KEY
- SESSION_SECRET  (random strong string)

## Endpoints
- GET /api/token?client=demo-cafe  → sets HttpOnly cookie if request comes from allowed domain for that client
- POST /api/chat  → requires cookie, checks origin + quota, calls OpenAI

## Demo client
See app/api/clients.ts — replace this with a Ninox fetch later.

## Embed
<script src="https://YOURDOMAIN.vercel.app/widget.js?client=demo-cafe&api=https://YOURDOMAIN.vercel.app"></script>
