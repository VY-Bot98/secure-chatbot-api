(function(){
  try {
    const src = document.currentScript && document.currentScript.src || "";
    const url = new URL(src);
    const clientSlug = url.searchParams.get("client");
    const apiBase = url.searchParams.get("api") || location.origin;
    if(!clientSlug){ console.warn("widget.js: missing ?client=slug"); return; }

    fetch(apiBase + '/api/token?client=' + encodeURIComponent(clientSlug), { credentials: 'include' })
      .finally(()=> initUI());

    function initUI(){
      const bubble = document.createElement('div');
      bubble.style.cssText = "position:fixed;right:20px;bottom:20px;width:56px;height:56px;border-radius:50%;background:#111;cursor:pointer;z-index:2147483647;box-shadow:0 4px 16px rgba(0,0,0,.2)";
      bubble.title = "Chat"; document.body.appendChild(bubble);

      const panel = document.createElement('div');
      panel.style.cssText = "position:fixed;right:20px;bottom:90px;width:360px;max-height:70vh;border:1px solid #e5e5e5;border-radius:12px;background:#fff;display:none;overflow:hidden;z-index:2147483647;box-shadow:0 10px 24px rgba(0,0,0,.16)";
      panel.innerHTML = '\
        <div style="padding:12px;border-bottom:1px solid #eee;font-weight:600">Welkom! 👋</div>\
        <div id="yv-log" style="padding:12px;max-height:46vh;overflow:auto;font-size:14px;line-height:1.4"></div>\
        <div style="display:flex;border-top:1px solid #eee">\
          <input id="yv-input" placeholder="Typ je vraag..." style="flex:1;padding:10px;border:0;outline:none"/>\
          <button id="yv-send" style="padding:10px 12px;border:0;background:#111;color:#fff">Send</button>\
        </div>';
      document.body.appendChild(panel);

      bubble.onclick = ()=> panel.style.display = (panel.style.display==='none'?'block':'none');

      const log = panel.querySelector('#yv-log');
      const input = panel.querySelector('#yv-input');
      const send = panel.querySelector('#yv-send');

      function add(role, text){
        const wrap = document.createElement('div');
        wrap.style.margin = '8px 0';
        wrap.innerHTML = '<div style="font-size:12px;color:#666">'+role+'</div><div>'+text+'</div>';
        log.appendChild(wrap); log.scrollTop = log.scrollHeight;
      }

      async function ask(){
        const content = (input.value||"").trim();
        if(!content) return;
        add('You', content); input.value='';
        try{
          const r = await fetch(apiBase + '/api/chat', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            credentials:'include',
            body: JSON.stringify({ clientSlug, messages:[{role:'user', content}] })
          });
          const data = await r.json();
          add('Bot', data.reply || data.error || '…');
        }catch(e){
          add('Bot', 'Er ging iets mis. Probeer later opnieuw.');
        }
      }
      send.onclick = ask;
      input.onkeydown = (e)=>{ if(e.key==='Enter') ask(); };
    }
  } catch(e) { console.error("widget.js error", e); }
})();