import { NextRequest, NextResponse } from "next/server";
import jwt from "jsonwebtoken";
import { CLIENTS } from "../clients";

const COOKIE_NAME = "sess";

export async function GET(req: NextRequest) {
  const clientSlug = req.nextUrl.searchParams.get("client") || "";
  const referer = req.headers.get("referer") || "";
  let host = "";
  try { host = new URL(referer).host; } catch {}

  const client = CLIENTS[clientSlug];
  if (!client || !client.is_active) {
    return NextResponse.json({ error: "Unknown or inactive client" }, { status: 404 });
  }
  if (!host || !client.allowed_domains.includes(host)) {
    return NextResponse.json({ error: "Forbidden origin" }, { status: 403 });
  }

  const token = jwt.sign({ sub: clientSlug, aud: host }, process.env.SESSION_SECRET!, { expiresIn: "1h" });

  const res = NextResponse.json({ ok: true });
  res.cookies.set(COOKIE_NAME, token, { httpOnly: true, sameSite: "lax", secure: true, maxAge: 3600, path: "/" });
  res.headers.set("Access-Control-Allow-Origin", `https://${host}`);
  res.headers.set("Vary", "Origin");
  return res;
}

export async function OPTIONS() {
  return new NextResponse(null, { status: 204 });
}
