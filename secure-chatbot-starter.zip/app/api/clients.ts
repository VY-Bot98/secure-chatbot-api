export type Client = {
  slug: string;
  name: string;
  language: string;
  tone: string;
  handover: string;
  support_email: string;
  knowledge?: string;
  monthly_quota: number;
  is_active: boolean;
  allowed_domains: string[];
};

export const CLIENTS: Record<string, Client> = {
  "demo-cafe": {
    slug: "demo-cafe",
    name: "Demo Café",
    language: "nl",
    tone: "vriendelijk en informeel",
    handover: "Mail ons op info@democafe.be",
    support_email: "info@democafe.be",
    knowledge: "We verkopen specialty coffee, openingsuren: ma-vr 9:00-18:00. Levering 2-3 werkdagen.",
    monthly_quota: 2000,
    is_active: true,
    allowed_domains: ["localhost", "127.0.0.1", "demo-client.local"]
  }
};
