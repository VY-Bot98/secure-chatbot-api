import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";
import jwt from "jsonwebtoken";
import { CLIENTS } from "../clients";

const COOKIE_NAME = "sess";
const usageStore: Record<string, { month: string; chats: number }> = {};
function monthKey(d = new Date()) { return `${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,"0")}`; }

export async function POST(req: NextRequest) {
  try {
    const token = req.cookies.get(COOKIE_NAME)?.value;
    if (!token) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    let payload:any;
    try { payload = jwt.verify(token, process.env.SESSION_SECRET!); }
    catch { return NextResponse.json({ error: "Unauthorized" }, { status: 401 }); }

    const { sub: clientSlug, aud } = payload as { sub: string; aud: string };
    const client = CLIENTS[clientSlug];
    if (!client || !client.is_active) return NextResponse.json({ error: "Inactive client" }, { status: 403 });

    const referer = req.headers.get("referer") || "";
    let host = ""; try { host = new URL(referer).host; } catch {}
    if (aud !== host || !client.allowed_domains.includes(host)) {
      return NextResponse.json({ error: "Forbidden origin" }, { status: 403 });
    }

    const { messages } = await req.json();
    if (!Array.isArray(messages)) return NextResponse.json({ error: "Bad request" }, { status: 400 });

    // quota by chats (simple). Replace with token-based if you prefer.
    const mk = monthKey();
    const u = usageStore[clientSlug] || { month: mk, chats: 0 };
    if (u.month !== mk) { u.month = mk; u.chats = 0; }
    if (u.chats >= client.monthly_quota) return NextResponse.json({ error: "Quota exceeded." }, { status: 429 });

    const system = `You are ${client.name}'s website assistant.
Language: ${client.language}. Tone: ${client.tone}.
If a question is out of scope or not covered, respond with: ${client.handover}.
When unsure, say you'll forward to support: ${client.support_email}.
Use ONLY the provided knowledge for business specifics; otherwise answer generically/helpfully.
Knowledge:
${(client.knowledge || "").slice(0, 12000)}`.trim();

    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY! });
    const completion = await openai.chat.completions.create({
      model: "gpt-4.1-mini",
      temperature: 0.3,
      messages: [{ role: "system", content: system }, ...messages]
    });

    const reply = completion.choices?.[0]?.message?.content || "…";

    u.chats += 1;
    usageStore[clientSlug] = u;

    const res = NextResponse.json({ reply });
    res.headers.set("Access-Control-Allow-Origin", `https://${host}`);
    res.headers.set("Vary", "Origin");
    return res;
  } catch (e:any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function OPTIONS() { return new NextResponse(null, { status: 204 }); }
